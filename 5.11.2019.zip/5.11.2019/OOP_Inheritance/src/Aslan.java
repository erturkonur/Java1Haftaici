
public class Aslan extends Kedigiller {
	public void vahsiOl() {
		System.out.println("Aslan vah�i oldu.");
	}
	public void sesCikar() {
		System.out.println("Aslan ses ��kard�.");
	}
	public void kosmaHizi(int kosma) {
		System.out.println("Aslan ko�u h�z�" + kosma);
	}
}
