
public class Kedi extends Kedigiller {
	public void evcilOl() {
		System.out.println("Kedi evcil oldu.");
	}
	public void sesCikar() {
		System.out.println("Kedi ses ��kard�.");
	}
	public void kosmaHizi(int kosma) {
		System.out.println("Kedi ko�u h�z�:" +kosma);
	}
	public void uyu() {
		super.uyu();
		System.out.println("Kedi uyudu.");
	}
}
