
public class Egitim {
	public void mufredat() {
	System.out.println("M�fredat");
	}
	public void materyal() {
	System.out.println("Materyal");
	}
}
