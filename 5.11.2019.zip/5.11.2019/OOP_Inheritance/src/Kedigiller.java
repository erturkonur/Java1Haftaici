
public class Kedigiller extends Hayvan {
	public void vahsiOl() {
		System.out.println("Kedigil vah�i oldu.");
	}
	public void yemekYe() {
		System.out.println("Kedigil yemek yedi.");
	}
	public void sesCikar() {
		System.out.println("Kedigil ses ��kard�.");
	}
	public void kosmaHizi(int kosma) {
		super.uyu();
		System.out.println("Kedigilin ko�u h�z�:" + kosma);
	}
}
