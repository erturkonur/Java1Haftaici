
public class Egitim_deneme {

	public static void main(String[] args) {
		Egitim egitim = new Egitim();
		egitim.materyal();
		egitim.mufredat();
		System.out.println("----");
		Ogrenci ogrenci = new Ogrenci();
		ogrenci.dersler();
		ogrenci.materyal();
		ogrenci.mufredat();
		ogrenci.sinif(2);
		System.out.println("----");
		Ogretmen ogretmen = new Ogretmen();
		ogretmen.adSoyad("A B");
		ogretmen.dersler();
		ogretmen.materyal();
		ogretmen.mufredat();
	}

}
