
public class MotorluTasitlar {
	private String marka;
	private String renk;
	private int tekerlekSayisi;
	private int vitesTuru; //0-duz vites,1-yar� otomatik,2-otomatik)
	private int yakitTuru; //(0-benzin,1-dizel,2-hybrid)
	private double beygirGucu;
	
	public void tur() {
		System.out.println("Motorlu Ta��t");
	}

	public int getTekerlekSayisi() {
		return tekerlekSayisi;
	}

	public void setTekerlekSayisi(int tekerlekSayisi) {
		this.tekerlekSayisi = tekerlekSayisi;
	}

	public String getRenk() {
		return renk;
	}

	public void setRenk(String renk) {
		this.renk = renk;
	}

	public double getBeygirGucu() {
		return beygirGucu;
	}

	public void setBeygirGucu(double beygirGucu) {
		this.beygirGucu = beygirGucu;
	}

	public int getYakitTuru() {
		return yakitTuru;
	}

	public void setYakitTuru(int yakitTuru) {
		this.yakitTuru = yakitTuru;
	}

	public String getMarka() {
		return marka;
	}

	public void setMarka(String marka) {
		this.marka = marka;
	}

	public int getVitesTuru() {
		return vitesTuru;
	}

	public void setVitesTuru(int vitesTuru) {
		this.vitesTuru = vitesTuru;
	}

	public MotorluTasitlar(int tekerlekSayisi, String renk, double beygirGucu, int yakitTuru, String marka,
			int vitesTuru) {
		this.tekerlekSayisi = tekerlekSayisi;
		this.renk = renk;
		this.beygirGucu = beygirGucu;
		this.yakitTuru = yakitTuru;
		this.marka = marka;
		this.vitesTuru = vitesTuru;
	}
	public MotorluTasitlar() {
		
	}
}
