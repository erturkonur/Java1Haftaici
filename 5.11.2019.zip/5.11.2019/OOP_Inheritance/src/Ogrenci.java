
public class Ogrenci extends Egitim {
	public void dersler() {
		System.out.println("��rencinin dersleri");
	}
	public void sinif(int sinif) {
		System.out.println("��rencinin s�n�f�: "+ sinif);
	}
}
