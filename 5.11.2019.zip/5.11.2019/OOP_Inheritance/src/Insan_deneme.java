
public class Insan_deneme {

	public static void main(String[] args) {
		
		Adem adem = new Adem();
		adem.avla();
		adem.konus();
		adem.nefesAl();
		adem.yemekYe();
		adem.uyu();
		adem.uyan();
		
		System.out.println("-----------");
		
		Insan insan = new Insan();
		insan.arabaSur();
		insan.iseGit();
		insan.kitapOku();
		insan.sarkiSoyle();
		insan.avla();
		insan.konus();
		insan.nefesAl();
		insan.yemekYe();
		insan.uyu();
		insan.uyan();
		

	}

}
