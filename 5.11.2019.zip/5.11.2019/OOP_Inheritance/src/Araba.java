
public class Araba extends MotorluTasitlar{
	public Araba(int tekerlekSayisi, String renk, double beygirGucu, int yakitTuru, String marka,
			int vitesTuru) {
		super(tekerlekSayisi,renk,beygirGucu,yakitTuru,marka,vitesTuru);
	}
	public void tur() {
		System.out.println("Araba");
	}
	public void yolcuSayisi() {
		System.out.println("Yolcu Say�s� : 5");
	}
}
