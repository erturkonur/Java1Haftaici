
public class Adem {
	public void yemekYe(){
		System.out.println("Adem yemek yedi.");
	}
	public void uyu() {
		System.out.println("Adem uyudu.");
	}
	public void uyan() {
		System.out.println("Adem uyand�.");
	}
	public void nefesAl() {
		System.out.println("Adem nefes ald�.");
	}
	public void konus() {
		System.out.println("Adem konu�tu.");
	}
	public void avla() {
		System.out.println("Adem avlad�.");
	}
}
