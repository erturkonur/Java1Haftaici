
public class Hayvan {
	//uyu,uyan,suIc,hareketTipi
	public void uyu() {
		System.out.println("Hayvan uyudu.");
	}
	public void uyan() {
		System.out.println("Hayvan uyand�.");
	}
	public void suIc() {
		System.out.println("Hayvan su i�ti.");
	}
	public void hareketTipi(String tip) {
		System.out.println("Hayvan hareketi:" + tip);
	}
}		
