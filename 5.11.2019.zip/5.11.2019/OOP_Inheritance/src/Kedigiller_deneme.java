
public class Kedigiller_deneme {

	public static void main(String[] args) {
		Kedi kedi = new Kedi();
		kedi.evcilOl();
		kedi.hareketTipi("y�r�r");
		kedi.kosmaHizi(15);
		kedi.sesCikar();
		kedi.suIc();
		// Kedi s�n�f�n�n �st s�n�f� olan kedigilde suIc metodu olmamas�na ra�men, kedigilin de �st s�n�f� olan hayvan
		// s�n�f�n�n metodu olan suIc() metodunu kedi s�n�f� dolayl� yoldan miras olarak alm�� oldu.
		kedi.vahsiOl(); // �st s�n�ftaki bir metodu do�rudan �a��rd�k.
		kedi.uyan();
		kedi.uyu();
		kedi.yemekYe();
		System.out.println("----");
		Panter panter = new Panter();
		panter.AgacaCik();
		panter.hareketTipi("ko�ar");
		panter.kosmaHizi(40);
		panter.sesCikar();
		panter.suIc();
		panter.uyan();
		panter.uyu();
		panter.vahsiOl();
		panter.yemekYe();
		System.out.println("----");
		Aslan aslan = new Aslan();
		aslan.hareketTipi("ko�ar");
		aslan.kosmaHizi(50);
		aslan.sesCikar();
		aslan.uyan();
		aslan.uyu();
		aslan.vahsiOl();
		aslan.yemekYe();
		Kedigiller kedigiller = new Kedigiller();
		kedigiller.hareketTipi("ko�ar");
		kedigiller.kosmaHizi(0);
		kedigiller.sesCikar();
		kedigiller.suIc();
		kedigiller.uyan();
		kedigiller.uyu();
		kedigiller.vahsiOl();
		kedigiller.yemekYe();
		Hayvan hayvan = new Hayvan();
	}

}
