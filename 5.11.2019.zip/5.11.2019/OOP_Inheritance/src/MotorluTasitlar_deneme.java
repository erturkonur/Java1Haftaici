import java.util.ArrayList;

public class MotorluTasitlar_deneme {

	public static void main(String[] args) {
		//int tekerlekSayisi, String renk, double beygirGucu, int yakitTuru, String marka,int vitesTuru
		ArrayList<MotorluTasitlar> araclar = new ArrayList<>();
		araclar.add(new Araba(4,"Beyaz",150,2,"Mercedes",1));
		araclar.add(new Kamyon(6,"K�rm�z�",300,0,"BMC",0));
		araclar.add(new Tir(8,"Siyah",400,1,"Scania",0));
		araclar.add(new SUV(4,"Mavi",250,2,"Mitsubishi",2));
		
		for (int i = 0; i < araclar.size(); i++) {
			System.out.println("Tekerlek Say�s�: " +  araclar.get(i).getTekerlekSayisi());
			System.out.println("Renk: " + araclar.get(i).getRenk());
			System.out.println("Beygir G�c�: " + araclar.get(i).getBeygirGucu());
			if (araclar.get(i).getYakitTuru()==0) {
				System.out.println("Yak�t T�r�: Benzin");
			}else if (araclar.get(i).getYakitTuru()==1) {
				System.out.println("Yak�t T�r�: Dizel");
			}
			else {
				System.out.println("Yak�t T�r�: Hybrid");
			}
			System.out.println("Marka: " + araclar.get(i).getMarka());
			if (araclar.get(i).getVitesTuru()==0) {
				System.out.println("Vites T�r�: Manuel");
			}
			else if (araclar.get(i).getVitesTuru() ==1) {
				System.out.println("Vites T�r�: Yar� Otomatik");
			}else {
				System.out.println("Vites T�r�: Otomatik");
			}
			System.out.println("----------");
		}
		for (MotorluTasitlar motorluTasitlar : araclar) {
			System.out.println("Tekerlerk Say�s�: " + motorluTasitlar.getTekerlekSayisi());
			System.out.println("Renk: " + motorluTasitlar.getRenk());
			System.out.println("Beygir G�c�: " + motorluTasitlar.getBeygirGucu());
			System.out.println("Yak�t T�r�: " + motorluTasitlar.getYakitTuru());
			System.out.println("Marka: " + motorluTasitlar.getMarka());
			System.out.println("Vites T�r� " + motorluTasitlar.getVitesTuru());
			motorluTasitlar.tur(); // Metot Override i�lemi yapt�k.
			System.out.println("**************");
			if (motorluTasitlar instanceof Araba) {
				Araba araba = (Araba)motorluTasitlar;
				araba.yolcuSayisi();
				
			}
			/*
			 ArrayList'e eklenen de�erlerin farkl� tipte oldu�unu biliyorsak ilgili s�n�f�n de�erlerini �a��rmak isteyebiliriz.
			 instanceof kelimesi sayesinde iki s�n�f�n ayn� tiplerde olup olmad���n� sorgular�z bu bize boolean de�er d�ner.
			 E�er tipleri ayn� ise, bir s�n�f� farkl� bir s�n�fa �evirebilirsiniz. (T�r d�n���m� yapabiliriz/Casting ��lemi)
			 Bu sayede cast etti�imiz s�n�ftaki �zellikleri ayr�ca g�rebiliriz.
			 */
		}
		
	}

}
