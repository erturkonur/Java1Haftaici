
public class Panter extends Kedigiller {
	public void AgacaCik() {
		System.out.println("Panter a�aca ��kt�.");
	}
}
