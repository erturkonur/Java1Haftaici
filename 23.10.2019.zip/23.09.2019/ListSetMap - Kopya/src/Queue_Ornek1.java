import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Queue_Ornek1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Queue<Integer> a = new LinkedList<>();
		Queue<String> kuyruk = new LinkedList<>();
		a.add(10);
		a.add(20);
		a.add(30);
		a.add(40);
		a.add(50);
		a.add(60);
		System.out.println("add metodu-> " + a);
		System.out.println(a);
		int peek = a.peek();
		System.out.println("peek metodu-> " + peek);
		System.out.println(a);
		int element = a.element();
		System.out.println("element metodu-> " + element);
		System.out.println(a);
		int remove = a.remove();
		System.out.println("remove metodu-> " +remove);
		System.out.println(a);
		int poll = a.poll();
		System.out.println("poll-> " + poll);
		System.out.println(a);
		int size = a.size();
		System.out.println("size-> " +size);
		System.out.println(a);
		System.out.println("******");
		for (int i = 0; i < 2; i++) {
			System.out.println("Kuyru�a eklenecek de�eri giriniz: \n---");
			String str = sc.next();
			if (kuyruk.add(str)) {
				System.out.println("De�er kuyru�a eklendi: "+str+"\n");
				
			}
		}
		kuyruk.poll(); // �lk s�radaki de�eri sildik.
		for (String string : kuyruk) { //T�m de�erleri listeledik.
			System.out.println(string);
			
		}
		
	}

}
