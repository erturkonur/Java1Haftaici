import java.util.HashMap;
import java.util.Scanner;

public class HashMap_Ornek1 {

	public static void main(String[] args) {
		/*
		 HashMap, Key(Anahtar) - Value(De�er) ili�kisinde de�er saklayabilmemizi sa�layan Map s�n�f�d�r.
		 HasHap belirtilen tipte Key ve yine ayr�ca belirtilen tipte Value almaktad�r.
		 */
		
		 HashMap<String,String> kelimeler = new HashMap<String,String>();
		 
		 kelimeler.put("elma", "apple");
		 kelimeler.put("kalem","pencil");
		 kelimeler.put("araba","car");
		 kelimeler.put("bilgisayar","computer");
		 
		 System.out.println(kelimeler.get("elma"));
		 System.out.println(kelimeler.isEmpty());
		 System.out.println(kelimeler.size());
		 System.out.println(kelimeler.containsKey("kalem"));
		 System.out.println(kelimeler.containsValue("car"));
		 System.out.println(kelimeler.values());
		 System.out.println(kelimeler.keySet());
		 System.out.println("*************");
		 
		 
		 /*
		  put - veri eklemek i�in kullan�l�r.
		  get - belirtilen key'e sahip eleman�n value(de�er) �a��rmak i�in kullan�l�r.
		  isEmpty - hashmap bo� mu dolu mu kontrol� sa�lar.
		  remove - belirtilen isimdeki tan�mlamay� siler.
		  size - hashmap'in eleman say�s�n� d�ner.
		  replace - ismi belirtilem key'in de�erini de�i�tirir.
		  containsKey - Bir anahtar�n varl���n� sorgulamak i�in kullan�l�r.
		  containsValue - Bir de�erin varl���n� sorgulamak i�in kullan�l�r.
		  values - T�m value'lar� d�nd�rmek i�in kullan�l�r.
		  keySet - t�m keyleri d�nd�rmek i�in kullan�l�r.
		  */
	}

}
