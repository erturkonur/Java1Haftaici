import java.util.Scanner;
import java.util.Vector;

public class Vector_Ornek3 {

	public static void main(String[] args) {
		Vector<String> degerler = new Vector<>(5);
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("De�er " +(i+1)+":");
			String deger = sc.next();
			degerler.addElement(deger);
		}
		
		System.out.println("Silmek istedi�iniz de�erin indisini belirleyiniz: ");
		int silinecek = sc.nextInt();
		degerler.remove(silinecek);
		
		for (String eleman : degerler) {
			System.out.println(eleman);
		}
	}

}
