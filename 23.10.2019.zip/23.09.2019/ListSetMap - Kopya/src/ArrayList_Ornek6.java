import java.util.ArrayList;

public class ArrayList_Ornek6 {

	public static void main(String[] args) {
		ArrayList<Object> nesne = new ArrayList<>();
		
		nesne.add(1);
		nesne.add("Merhaba");
		nesne.add(true);
		
		System.out.println(nesne.get(0));
		System.out.println(nesne.get(1));
		System.out.println(nesne.get(2));

	}

}
