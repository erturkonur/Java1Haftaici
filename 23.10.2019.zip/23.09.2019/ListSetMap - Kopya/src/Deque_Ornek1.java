import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

public class Deque_Ornek1 {

	public static void main(String[] args) {
		Deque<Integer> a = new LinkedList<>();
		Deque<Integer> sayilar = new LinkedList<>();
		a.add(10);
		a.add(20);
		a.add(30);
		a.add(40);
		a.add(50);
		a.add(60);
		System.out.println("add metodu-> " + a);
		int peek = a.peek();
		System.out.println("peek metodu-> " + peek);
		System.out.println(a);
		int element = a.element();
		System.out.println("element metodu-> " + element);
		System.out.println(a);
		int remove = a.remove();
		System.out.println("remove metodu-> " +remove);
		System.out.println(a);
		int poll = a.poll();
		System.out.println("poll-> " + poll);
		System.out.println(a);
		int size = a.size();
		System.out.println("size-> " +size);
		System.out.println(a);
		a.addFirst(20);
		System.out.println("addFirst metodu-> " +a);
		a.addLast(70);
		System.out.println("addLast metodu-> " +a);
		a.offer(80);
		System.out.println("offer metodu-> " +a);
		System.out.println("----");
		Iterator iterator = a.iterator();
		while (iterator.hasNext()) 
            System.out.println(iterator.next()); 
		Iterator reverse = a.descendingIterator();
		System.out.println("----");
		while (reverse.hasNext())
			System.out.println(reverse.next());
		
		System.out.println("*************");
		
		sayilar.offer(10);
		sayilar.offer(50);
		sayilar.offer(40);
		sayilar.offer(150);
		sayilar.offer(160);
		
		System.out.println(sayilar);
		for (int i = 0; i < sayilar.size()+i; i++) {
			System.out.println(sayilar.poll());
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
