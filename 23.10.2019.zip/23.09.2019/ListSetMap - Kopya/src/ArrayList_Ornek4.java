import java.util.ArrayList;

public class ArrayList_Ornek4 {

	public static void main(String[] args) {
		ArrayList<String> yazilar = new ArrayList<>();
		yazilar.add("B�LG�SAYAR");
		yazilar.add("TELEV�ZYON");
		yazilar.add("KOLTUK");
		yazilar.add("ARABA");
		
		// Foreach ile liste elemanlar�n� listeleme.
		System.out.println("Listedeki de�erler: ");
		for (String eleman : yazilar) {
			System.out.println(eleman);
		}
		System.out.println("****************");
		// Remove metodu sayesinde string arg�man g�ndererek de�er sildik.
		System.out.println("Listeden koltuk eleman�n� silme");
		String silinecekKelime = "KOLTUK";
		yazilar.remove(silinecekKelime);
		System.out.println("Listenin son hali: ");
		for (String eleman : yazilar) {
			System.out.println(eleman);
		}

	}

}
