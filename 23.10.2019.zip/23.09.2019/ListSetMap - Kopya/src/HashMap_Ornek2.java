import java.util.HashMap;
import java.util.Scanner;

public class HashMap_Ornek2 {

	public static void main(String[] args) {
		 HashMap<String,String> kelime = new HashMap<String,String>();
		 Scanner sc = new Scanner(System.in);
		 System.out.print("Anahar ve de�er say�s� giriniz: ");
		 int N = sc.nextInt();
		 for (int i = 0; i < N; i++) {
			System.out.print("Anahtarlar� giriniz: ");
			String anahtar = sc.next();
			System.out.print("De�erleri giriniz: ");
			String deger = sc.next();
			kelime.put(anahtar,deger);
		}
		System.out.println("Keys: " + kelime.keySet());
		System.out.println("Value: " +kelime.values());
		System.out.println("Aramak istedi�iniz anahtar� giriniz: ");
		String aranan = sc.next();
		if (kelime.containsKey(aranan)) {
			System.out.println("Arad���n�z de�er anahtar i�inde bulunmaktad�r.");
			System.out.println(kelime.get(aranan));
		}else {
			System.out.println("Arad���n�z de�er anahtar i�inde bulunmamaktad�r.");
		}

	}

}
