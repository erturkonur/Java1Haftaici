import java.util.ArrayList;

public class ArrayList_Ornek8 {

	public static void main(String[] args) {
		ArrayList <araba> arabalar = new ArrayList<>();
		arabalar.add(new araba("Opel","Astra",90000,"Beyaz"));
		arabalar.add(new araba("Toyota","Corolla",80000,"Gri"));
		arabalar.add(new araba("BMW","M3",250000,"K�rm�z�"));
		arabalar.add(new araba("Bugatti","Chiron",3000000,"Siyah"));
		
		for (araba araba : arabalar) {
			System.out.println("Araban�n markas�: " + araba.getMarka());
			System.out.println("Araban�n modeli: " + araba.getModel());
			System.out.println("Araban�n fiyat�: " + araba.getFiyat());
			System.out.println("Araban�n rengi: " + araba.getRenk());
			System.out.println("***");
		}
		
		System.out.println("-------------------");
		for (int i = 0; i < arabalar.size(); i++) {
			System.out.println("Araban�n markas�: " + arabalar.get(i).getMarka());
			System.out.println("Araban�n modeli: " + arabalar.get(i).getModel());
			System.out.println("Araban�n fiyat�: " + arabalar.get(i).getFiyat());
			System.out.println("Araban�n rengi: " + arabalar.get(i).getRenk());
			System.out.println("***");
		}

	}

}
