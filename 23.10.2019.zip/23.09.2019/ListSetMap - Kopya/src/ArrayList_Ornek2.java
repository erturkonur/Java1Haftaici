import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek2 {

	public static void main(String[] args) {
		
		ArrayList<String> degerler = new ArrayList<>(); 
		Scanner sc = new Scanner(System.in);
		System.out.println("Girmek istedi�iniz de�er say�s�n� giriniz:");
		int N = sc.nextInt();
		for (int i = 0; i < N; i++) {
			System.out.println("De�erleri giriniz:");
			String deger = sc.next();
			degerler.add(deger);
		}
		for (int i = 0; i < degerler.size(); i++) {
			System.out.println("De�er-" +(i+1)+": "+ degerler.get(i));
		}
	}

}
