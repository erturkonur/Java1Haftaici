import java.util.HashMap;
import java.util.Scanner;

public class HashMap_Ornek3 {

	public static void main(String[] args) {
		HashMap<String,Integer> ilce = new HashMap<String,Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("5 adet il�e ve posta kodu giriniz: ");
		for (int i = 0; i < 5; i++) {
			System.out.print("�l�e ad�: ");
			String ilceAdi = sc.next();
			System.out.print("Posta kodu: ");
			int postaKodu = sc.nextInt();
			ilce.put(ilceAdi, postaKodu);
		}
		System.out.println("�l�eler: "+ilce.keySet());
		System.out.println("Posta Kodlar�: "+ilce.values());
		System.out.println("*******");
		
		for (Integer postaKodu : ilce.values()) {
			System.out.println(postaKodu);
		}
		
		for (String ilceAdi : ilce.keySet()) {
			System.out.println(ilceAdi);
		}
		
		//HashTable, HashSet, TreeSet i�lenmedi.
		

	}
}
