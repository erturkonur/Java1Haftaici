import java.util.Stack;

public class Stack_Ornek1 {

	public static void main(String[] args) {
		
		Stack stc = new Stack();
		/*
		 Stack s�n�f� vektor s�n�f�ndan t�remi�tir. Bu nedenle stack s�n�f� i�ersinde vektorde bulunan metot isimleri
		 ile kar��la��lablir.
		 Vector'de olmay�p stackde ayr�ca eklenmi� metot isimleri ile kar��la�abiliriz.
		 */
		
		/*
		 add
		 addElement
		 capacity
		 elements
		 elementsAt
		 firstElement
		 lastElement
		 get
		 isEmpty
		 lastIndexOf
		 indexOf
		 removeAllElement
		 clear
		 
		 empty
		 peek
		 pop
		 push
		 search
		 */
		
	}

}
