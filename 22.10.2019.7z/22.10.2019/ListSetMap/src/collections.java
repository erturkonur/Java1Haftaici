
public class collections {

	public static void main(String[] args) {
		/* 
		 Java Generic(Collections)
		 - List
		 -- List
		 -- ArrayList
		 -- LinkedList
		 -- Vector
		 -- Stack
		 - Set
		 -- HashSet
		 -- HashTable
		 -- LinkedHashSet
		 - Map
		 -- HashMap
 		 
		 */

	}

}
