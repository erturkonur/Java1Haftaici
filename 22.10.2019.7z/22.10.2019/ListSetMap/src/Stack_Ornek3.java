import java.util.Stack;

public class Stack_Ornek3 {

	public static void main(String[] args) {
		/*
		 push
		 - Listenin eleman ekleme i�lemi yapar.
		 pop
		 - Listenin son  eleman�n� siler. E�er liste bo� ise EmptyStackException hatas� verir.
		 peek
		 - Listenin son eleman�n� d�nd�r�r. Eleman� sinmez, sadece g�sterir.
		 empty
		 -Listenin bo� olup olmama durumunu kontrol eder.
		 search
		 - Listede eleman arama i�lemi yapmam�z i�in kullan�l�r. Eleman listede varsa indisini d�ner, listede yoksa -1 d�ner.
		 */
		
		Stack stc = new Stack();
		stc.add(10);
		stc.add(20);
		stc.add(30);
		stc.add(40);
		stc.add(50);
		stc.add(60);
		System.out.println(stc.pop());
		stc.push(70);
		System.out.println("-----");
		System.out.println(stc);
		System.out.println("-----");
		System.out.println(stc.peek());
		System.out.println("-----");
		System.out.println(stc.empty());
		System.out.println("-----");
		System.out.println(stc.search(40));
		System.out.println("-----");
		System.out.println(stc.search(25));
		System.out.println("-----");
		Stack<String> stack = new Stack();
		stack.push("MECL�S�");
		stack.push("M�LLET");
		stack.push("B�Y�K");
		stack.push("T�RK�YE");
		
		for (int i = 0; i < 4; i++) {
			System.out.println(stack.pop());
		}
	}

}
