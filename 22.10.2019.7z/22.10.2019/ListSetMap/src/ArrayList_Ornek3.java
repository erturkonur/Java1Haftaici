import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek3 {

	public static void main(String[] args) {
		ArrayList<Integer> sayilar = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Ka� adet say� gireceksiniz: ");
		int adet =sc.nextInt();
		
		for (int i = 0; i < adet; i++) {
			System.out.println((i+1)+"."+"say�:");
			int sayi = sc.nextInt();
			sayilar.add(sayi);
		}
		
		System.out.print("Silmek istedi�iniz indis de�erini giriniz: ");
		int sayi2 = sc.nextInt();
		sayilar.remove(sayi2);
		System.out.println("ArrayList: "+ sayilar);
		for (int i = 0; i <sayilar.size(); i++) {
			System.out.println(sayilar.get(i));
		}
	}	

}
