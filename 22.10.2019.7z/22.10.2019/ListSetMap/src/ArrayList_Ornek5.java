import java.util.ArrayList;

public class ArrayList_Ornek5 {
	
	public static void sehirleriListele(ArrayList<String> sehirler,char ch) {
		System.out.println("\n"+ch+ " ile ba�layan �ehirleri listeleyim");
		for (String eleman : sehirler) {
			if (eleman.charAt(0) == ch) {
				System.out.println(eleman);
			}
		}
		
		
	}
	
	

	public static void main(String[] args) {
		ArrayList<String> sehirler = new ArrayList<>();
		sehirler.add("�stanbul");
		sehirler.add("Ankara");
		sehirler.add("Bursa");
		sehirler.add("Bolu");
		sehirler.add("Antalya");
		sehirler.add("�zmir");
		
		sehirleriListele(sehirler,'�');
		sehirleriListele(sehirler,'A');
	}

}
