import java.util.ArrayList;

public class ArrayList_Ornek9 {

	public static void main(String[] args) {
		ArrayList<String> meyveler = new ArrayList<>();
		
		meyveler.add("Elma");
		meyveler.add("�ilek");
		meyveler.add("Nar");
		meyveler.add("Kavun");
		meyveler.add("Kiraz");
		
		// T�m elemanlar� listeledik.
		for (String eleman : meyveler) {
			System.out.println(eleman);
		}
		meyveler.remove(1); // Listeden �ile�i sildik.
		
		System.out.println("------");
		
		// T�m elemanlar� listeledik.
		for (String eleman : meyveler) {
			System.out.println(eleman);
		}
		
		System.out.println("------");
		
		for (int i = 0; i < meyveler.size(); i++) {
			System.out.println(meyveler.get(i));
		}
		
		meyveler.clear(); // T�m elemanlar� siler.
		
		System.out.println("------");
		
		if(meyveler.isEmpty()) {
			System.out.println("Meyveler listesi bo�");
		}else {
			System.out.println("Meyveler liste dolu");
		}
	}

}
