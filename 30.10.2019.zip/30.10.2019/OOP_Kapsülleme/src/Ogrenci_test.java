import java.util.ArrayList;

public class Ogrenci_test {

	public static void main(String[] args) {
		
		// Set metotlar� ile nesne de�i�ken de�erlerini doldurmak
		Ogrenci ogrenci = new Ogrenci();
		ogrenci.setAdSoyad("�erif G�ng�r");
		ogrenci.setBolumAdi("Bilgisayar Programc�l���");
		ogrenci.setBolumYil(2013);
		ogrenci.setCinsiyet('e');
		ogrenci.setDogumYili(1994);
		ogrenci.setNotOrtalamasi(3.06);
		ogrenci.setOgrenciNo(2013.01);
		ogrenci.setOkulAdi("�stanbul Ticaret �niversitesi");
		
		System.out.println("��rencinin ad� ve soyad�: " + ogrenci.getAdSoyad());
		System.out.println("��rencinin okula ba�lama tarihi: "+ogrenci.getBolumYil());
		System.out.println("��rencinin not ortalamas�: " +ogrenci.getNotOrtalamasi());
		System.out.println("��rencinin numaras�: " +ogrenci.getOgrenciNo());
		System.out.println("��rencinin cinsiyeti: " + ogrenci.getCinsiyet());
		System.out.println("��rencinin do�um y�l�: " +ogrenci.getDogumYili());
		System.out.println("��rencinin okulu: " + ogrenci.getOkulAdi());
		System.out.println("��rencinin b�l�m�: " +ogrenci.getBolumAdi());
		
		//Dolu constructor seviyesinde, nesne de�i�ken de�erlerini doldurmak
		
		Ogrenci ogrenci2 = new Ogrenci("Ad Soyad",100,'k',1990,"�stanbul �niversitesi","Bilgisayar M�hendisli�i", 2010, 3.30);
		/*String adSoyad,double ogrenciNo,char cinsiyet ,int dogumYili,String okulAdi, String bolumAdi,int bolumYil,double notOrtalamasi
		
		/*ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
		ogrenciler.add(new Ogrenci("Ahmet Keser",202,'e',1992,"�stanbul Universitesi","G�da M�hendisli�i",5, 2.38));
		for (Ogrenci ogrenci : ogrenciler) {
			System.out.println("��rencinin ad� ve soyad�: " + ogrenci.getAdSoyad());
			System.out.println("��rencinin numaras�: " + ogrenci.getOgrenciNo());
			System.out.println("��rencinin cinsiyeti: " + ogrenci.getCinsiyet());
			System.out.println("��rencinin do�um y�l�: " + ogrenci.getDogumYili());
			System.out.println("��rencinin okulu: " + ogrenci.getOkulAdi());
			System.out.println("��rencinin b�l�m�: " + ogrenci.getBolumAdi());
			System.out.println("��rencinin b�l�mdeki y�l�: "+ ogrenci.getBolumYil());
			System.out.println("��rencinin ortalamas�: " + ogrenci.getNotOrtalamasi());
			
		}
	*/
	}

}
