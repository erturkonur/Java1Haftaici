import java.util.ArrayList;
import java.util.Scanner;

public class Telefon_test {

	public static void main(String[] args) {
		ArrayList<Telefon> telefonn = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Telefon say�s�n� giriniz:");
		int N = sc.nextInt();
		
		for (int i = 0; i < N; i++) {
			
			System.out.println("Telefon markas�: ");
			String marka = sc.next();
			System.out.println("Telefon modeli: ");
			String model = sc.next();
			System.out.println("Telefon rengi: ");
			String renk = sc.next();
			System.out.println("Telefon i�letim sistemi: ");
			String isletim = sc.next();
			System.out.println("Telefon �retim y�l�: ");
			int yil = sc.nextInt();
			telefonn.add(new Telefon(marka,model,renk,isletim,yil));
			System.out.println("****************");
			
		}
		
		
		for (Telefon telefon : telefonn) {
			System.out.println("Telefon markas�: " + telefon.getMarka());
			System.out.println("Telefon modeli: " + telefon.getModel());
			System.out.println("Telefon rengi: " + telefon.getRenk());
			System.out.println("Telefon i�letim sistemi: " + telefon.getI�letimSistemi());
			System.out.println("Telefon �retim y�l�: " + telefon.getUretimYili());
			System.out.println("---------------");
		}
		
		/*Telefon telefon = new Telefon(marka, model, renk, isletim, yil);
		
		System.out.println("Telefon markas�: " + telefon.getMarka());
		System.out.println("Telefon modeli: " + telefon.getModel());
		System.out.println("Telefon rengi: " + telefon.getRenk());
		System.out.println("Telefon i�letim sistemi: " + telefon.getI�letimSistemi());
		System.out.println("Telefon �retim y�l�: " + telefon.getUretimYili());
		*/
	}

}
