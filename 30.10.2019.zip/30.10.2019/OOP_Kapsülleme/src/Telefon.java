
public class Telefon {
		
		private String marka;
		private String model;
		private String renk;
		private String i�letimSistemi;
		private int uretimYili;
		
		public String getMarka() {
			return marka;
		}
		public void setMarka(String marka) {
			this.marka = marka;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public String getRenk() {
			return renk;
		}
		public void setRenk(String renk) {
			this.renk = renk;
		}
		public String getI�letimSistemi() {
			return i�letimSistemi;
		}
		public void setI�letimSistemi(String i�letimSistemi) {
			this.i�letimSistemi = i�letimSistemi;
		}
		public int getUretimYili() {
			return uretimYili;
		}
		public void setUretimYili(int uretimYili) {
			this.uretimYili = uretimYili;
		}
		public Telefon(String marka, String model, String renk, String i�letimSistemi, int uretimYili) {
			super();
			this.marka = marka;
			this.model = model;
			this.renk = renk;
			this.i�letimSistemi = i�letimSistemi;
			this.uretimYili = uretimYili;
		}
		
		
		
		
}

