import java.util.ArrayList;

public class Ders {
	private String dersAdi;
	private String ogretmenAdSoyad;
	private String sinifAdi;
	private int haftalikSaat;
	private int kredi;
	private ArrayList<Ogrenci> ogrenciler;
	public String getDersAdi() {
		return dersAdi;
	}
	public void setDersAdi(String dersAdi) {
		this.dersAdi = dersAdi;
	}
	public String getOgretmenAdSoyad() {
		return ogretmenAdSoyad;
	}
	public void setOgretmenAdSoyad(String ogretmenAdSoyad) {
		this.ogretmenAdSoyad = ogretmenAdSoyad;
	}
	public String getSinifAdi() {
		return sinifAdi;
	}
	public void setSinifAdi(String sinifAdi) {
		this.sinifAdi = sinifAdi;
	}
	public int getHaftalikSaat() {
		return haftalikSaat;
	}
	public void setHaftalikSaat(int haftalikSaat) {
		this.haftalikSaat = haftalikSaat;
	}
	public int getKredi() {
		return kredi;
	}
	public void setKredi(int kredi) {
		this.kredi = kredi;
	}
	public ArrayList<Ogrenci> getOgrenciler() {
		return ogrenciler;
	}
	public void setOgrenciler(ArrayList<Ogrenci> ogrenciler) {
		this.ogrenciler = ogrenciler;
	}
	public Ders() {
		
	}
	public Ders(String dersAdi, String ogretmenAdSoyad, String sinifAdi, int haftalikSaat, int kredi,
			ArrayList<Ogrenci> ogrenciler) {
		super();
		this.dersAdi = dersAdi;
		this.ogretmenAdSoyad = ogretmenAdSoyad;
		this.sinifAdi = sinifAdi;
		this.haftalikSaat = haftalikSaat;
		this.kredi = kredi;
		this.ogrenciler = ogrenciler;
	}
	
	
}
