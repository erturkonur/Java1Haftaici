import java.util.ArrayList;

public class Deneme {

	public static void main(String[] args) {
		//int ogrenciNo, int ogrenciSinif, int okulaGirisYili, int ogrenciDogumYili, String adSoyad,String telefonNo, char cinsiyet, double notOrtalamasi
		ArrayList<Ogrenci> bilgMuhOgrencileri = new ArrayList<>();
		bilgMuhOgrencileri.add(new Ogrenci(1,1,2019,2000,"Ad Soyad","+902125212012",'k',3.20));
		bilgMuhOgrencileri.add(new Ogrenci(2,1,2013,1995,"Ad Soyad","+902125312412",'e',3.10));
		bilgMuhOgrencileri.add(new Ogrenci(3,1,2014,1996,"Ad Soyad","+902125212532",'k',2.20));
		bilgMuhOgrencileri.add(new Ogrenci(4,1,2012,1997,"Ad Soyad","+902125215046",'e',1.20));
		ArrayList<Ogrenci> elkMuhOgrencileri = new ArrayList<>();
		elkMuhOgrencileri.add(new Ogrenci(2,3,2012,1995,"Ad Soyad","+902125325032",'e',2.54));
		//String dersAdi, String ogretmenAdSoyad, String sinifAdi, int haftalikSaat, int kredi,ArrayList<Ogrenci> ogrenciler
		ArrayList<Ders> dersler = new ArrayList<>();
		dersler.add(new Ders("Java Programlama","�erif G�ng�r","Lab09",8,4,bilgMuhOgrencileri));
		dersler.add(new Ders("Temel Elektrik","Ad Soyad","Lab01",6,3,elkMuhOgrencileri));
		//String bolumAdi, int kontenjanSayisi, ArrayList<Ders> dersler, ArrayList<Ogrenci> ogrenciler
		ArrayList<Bolum> bolumler = new ArrayList<>();
		bolumler.add(new Bolum("Bilgisayar M�hendisli�i",240,dersler,bilgMuhOgrencileri));
		bolumler.add(new Bolum("Elektrik M�hendisli�i",160,dersler,elkMuhOgrencileri));
		//String ad, String adres, ArrayList<Bolum> bolumler
		ArrayList<Kampus> kampusler = new ArrayList<>();
		kampusler.add(new Kampus("Be�ikta� Kamp�s�","�stanbul/Be�ilta�",bolumler));
		kampusler.add(new Kampus("Davutpa�a Kamp�s�","�stanbul/Esenler",bolumler));
		kampusler.add(new Kampus("Ayaza�a Kamp�s�","�stanbul/Sar�yer",bolumler));
		Kampus kampus = new Kampus();
		//String ad, String �lke, String telefonNo, ArrayList<Kampus> kampusler
		Universite universite = new Universite("Y�ld�z Teknik �niversitesi","T�rkiye","+902122520125",kampusler);
		
			for(Ogrenci ogrenci : universite.getKampusler().get(0).getBolumler().get(1).getDersler().get(1).getOgrenciler()){
				System.out.println("��rencinin ad�:" + ogrenci.getAdSoyad());
				System.out.println("��rencinin do�um y�l�: " + ogrenci.getOgrenciDogumYili());
		}
		
		//int ogrenciNo, int ogrenciSinif, int okulaGirisYili, int ogrenciDogumYili, String adSoyad,String telefonNo, char cinsiyet, double notOrtalamasi
		
	}

}
