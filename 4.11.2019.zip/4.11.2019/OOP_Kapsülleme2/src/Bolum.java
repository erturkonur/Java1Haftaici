import java.util.ArrayList;

public class Bolum {
	private String bolumAdi;
	private int kontenjanSayisi;
	private ArrayList<Ders> dersler;
	private ArrayList<Ogrenci> ogrenciler;
	public String getBolumAdi() {
		return bolumAdi;
	}
	public void setBolumAdi(String bolumAdi) {
		this.bolumAdi = bolumAdi;
	}
	public int getKontenjanSayisi() {
		return kontenjanSayisi;
	}
	public void setKontenjanSayisi(int kontenjanSayisi) {
		this.kontenjanSayisi = kontenjanSayisi;
	}
	public ArrayList<Ders> getDersler() {
		return dersler;
	}
	public void setDersler(ArrayList<Ders> dersler) {
		this.dersler = dersler;
	}
	public ArrayList<Ogrenci> getOgrenciler() {
		return ogrenciler;
	}
	public void setOgrenciler(ArrayList<Ogrenci> ogrenciler) {
		this.ogrenciler = ogrenciler;
	}
	public Bolum () {
		
	}
	public Bolum(String bolumAdi, int kontenjanSayisi, ArrayList<Ders> dersler, ArrayList<Ogrenci> ogrenciler) {
		super();
		this.bolumAdi = bolumAdi;
		this.kontenjanSayisi = kontenjanSayisi;
		this.dersler = dersler;
		this.ogrenciler = ogrenciler;
	}
	
}
