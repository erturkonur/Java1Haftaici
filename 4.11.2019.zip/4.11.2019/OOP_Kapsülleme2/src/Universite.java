import java.util.ArrayList;

public class Universite {
	private String ad;
	private String �lke;
	private String telefonNo;
	private ArrayList<Kampus> kampusler;
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String get�lke() {
		return �lke;
	}
	public void set�lke(String �lke) {
		this.�lke = �lke;
	}
	public String getTelefonNo() {
		return telefonNo;
	}
	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}
	public ArrayList<Kampus> getKampusler() {
		return kampusler;
	}
	public void setKampusler(ArrayList<Kampus> kampusler) {
		this.kampusler = kampusler;
	}
	public Universite() {
		
	}
	public Universite(String ad, String �lke, String telefonNo, ArrayList<Kampus> kampusler) {
		super();
		this.ad = ad;
		this.�lke = �lke;
		this.telefonNo = telefonNo;
		this.kampusler = kampusler;
	}
	
}
