
public class Ogrenci {
	private int ogrenciNo;
	private int ogrenciSinif;
	private int okulaGirisYili;
	private int ogrenciDogumYili;
	private String adSoyad;
	private String telefonNo;
	private char cinsiyet;
	private double notOrtalamasi;
	public int getOgrenciNo() {
		return ogrenciNo;
	}
	public void setOgrenciNo(int ogrenciNo) {
		this.ogrenciNo = ogrenciNo;
	}
	public int getOgrenciSinif() {
		return ogrenciSinif;
	}
	public void setOgrenciSinif(int ogrenciSinif) {
		this.ogrenciSinif = ogrenciSinif;
	}
	public int getOkulaGirisYili() {
		return okulaGirisYili;
	}
	public void setOkulaGirisYili(int okulaGirisYili) {
		this.okulaGirisYili = okulaGirisYili;
	}
	public int getOgrenciDogumYili() {
		return ogrenciDogumYili;
	}
	public void setOgrenciDogumYili(int ogrenciDogumYili) {
		this.ogrenciDogumYili = ogrenciDogumYili;
	}
	public String getAdSoyad() {
		return adSoyad;
	}
	public void setAdSoyad(String adSoyad) {
		this.adSoyad = adSoyad;
	}
	public String getTelefonNo() {
		return telefonNo;
	}
	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}
	public char getCinsiyet() {
		return cinsiyet;
	}
	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}
	public double getNotOrtalamasi() {
		return notOrtalamasi;
	}
	public void setNotOrtalamasi(double notOrtalamasi) {
		this.notOrtalamasi = notOrtalamasi;
	}
	public Ogrenci() {
		
	}
	public Ogrenci(int ogrenciNo, int ogrenciSinif, int okulaGirisYili, int ogrenciDogumYili, String adSoyad,
			String telefonNo, char cinsiyet, double notOrtalamasi) {
		super();
		this.ogrenciNo = ogrenciNo;
		this.ogrenciSinif = ogrenciSinif;
		this.okulaGirisYili = okulaGirisYili;
		this.ogrenciDogumYili = ogrenciDogumYili;
		this.adSoyad = adSoyad;
		this.telefonNo = telefonNo;
		this.cinsiyet = cinsiyet;
		this.notOrtalamasi = notOrtalamasi;
	}
	
}
