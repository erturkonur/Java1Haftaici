
public class Ogrenci {

	private String adSoyad;
	private double ogrenciNo;
	private char cinsiyet;
	private int dogumYili;
	private String okulAdi;
	private String bolumAdi;
	private int bolumYil;
	private double notOrtalamasi;
	/* E�er neseneleri public eri�im seviyesinde yazm�� olsayd�k, constructor ve getter/setter metotlara hi� ihtiya� duymazd�k.
	 Nesneleri �zellikle private olarak belirtiyoruz ki, ilgili nesne de�erine eri�ebilmesi ya da de�i�tirilebilmesi i�in
	 bir metot kullanmaya zorluyoruz. Bu i�i g�venlik mekanizmas�n� artt�rabilmek i�in yap�yoruz.
	 
	*/
	
	// Bo� constructor
	public Ogrenci() {
	}
	
	// Dolu constructor
	public Ogrenci(String adSoyad,double ogrenciNo,char cinsiyet ,int dogumYili,String okulAdi, String bolumAdi,int bolumYil,double notOrtalamasi) {
		
		this.adSoyad = adSoyad;
		this.ogrenciNo = ogrenciNo;
		this.cinsiyet = cinsiyet;
		this.dogumYili = dogumYili;
		this.okulAdi = okulAdi;
		this.bolumAdi = bolumAdi;
		this.bolumYil = bolumYil;
		this.notOrtalamasi = notOrtalamasi;
	}
	
	// Set metotlar atama yapmak i�in kullan�l�r. �lgili de�i�kenleri de�i�tirmek i�in kullan�l�r.
	public void setAdSoyad(String adSoyad) {
		this.adSoyad = adSoyad;
	}
	// Get metotlar ise, ilgili de�i�ken de�erleri �a��rmak i�in kullan�l�r.
	public String getAdSoyad() {
		return adSoyad;
	}

	public double getOgrenciNo() {
		return ogrenciNo;
	}

	public void setOgrenciNo(double ogrenciNo) {
		this.ogrenciNo = ogrenciNo;
	}

	public char getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public int getDogumYili() {
		return dogumYili;
	}

	public void setDogumYili(int dogumYili) {
		this.dogumYili = dogumYili;
	}

	public String getOkulAdi() {
		return okulAdi;
	}

	public void setOkulAdi(String okulAdi) {
		this.okulAdi = okulAdi;
	}

	public String getBolumAdi() {
		return bolumAdi;
	}

	public void setBolumAdi(String bolumAdi) {
		this.bolumAdi = bolumAdi;
	}

	public int getBolumYil() {
		return bolumYil;
	}

	public void setBolumYil(int bolumYil) {
		this.bolumYil = bolumYil;
	}

	public double getNotOrtalamasi() {
		return notOrtalamasi;
	}

	public void setNotOrtalamasi(double notOrtalamasi) {
		this.notOrtalamasi = notOrtalamasi;
	}
	
	
	
	
}
