
public class Cicek {
	private String renk;
	private String isim;
	private String tur;
	private String mevsim;
	private boolean koku;
	private boolean diken;
	private boolean saksi;
	private boolean meyve;
	private int omur; // �i�e�in ya�abilece�i g�n say�s�
	private int yukseklik;
	private int yaprakSayisi;
	public String getRenk() {
		return renk;
	}
	public void setRenk(String renk) {
		this.renk = renk;
	}
	public String getIsim() {
		return isim;
	}
	public void setIsim(String isim) {
		this.isim = isim;
	}
	public String getTur() {
		return tur;
	}
	public void setTur(String tur) {
		this.tur = tur;
	}
	public String getMevsim() {
		return mevsim;
	}
	public void setMevsim(String mevsim) {
		this.mevsim = mevsim;
	}
	public boolean isKoku() {
		return koku;
	}
	public void setKoku(boolean koku) {
		this.koku = koku;
	}
	public boolean isDiken() {
		return diken;
	}
	public void setDiken(boolean diken) {
		this.diken = diken;
	}
	public boolean isSaksi() {
		return saksi;
	}
	public void setSaksi(boolean saksi) {
		this.saksi = saksi;
	}
	public boolean isMeyve() {
		return meyve;
	}
	public void setMeyve(boolean meyve) {
		this.meyve = meyve;
	}
	public int getOmur() {
		return omur;
	}
	public void setOmur(int omur) {
		this.omur = omur;
	}
	public int getYukseklik() {
		return yukseklik;
	}
	public void setYukseklik(int yukseklik) {
		this.yukseklik = yukseklik;
	}
	public int getYaprakSayisi() {
		return yaprakSayisi;
	}
	public void setYaprakSayisi(int yaprakSayisi) {
		this.yaprakSayisi = yaprakSayisi;
	}
	public Cicek() {
}
	public Cicek(String renk, String isim, String tur, String mevsim, boolean koku, boolean diken, boolean saksi,
			boolean meyve, int omur, int yukseklik, int yaprakSayisi) {
		super();
		this.renk = renk;
		this.isim = isim;
		this.tur = tur;
		this.mevsim = mevsim;
		this.koku = koku;
		this.diken = diken;
		this.saksi = saksi;
		this.meyve = meyve;
		this.omur = omur;
		this.yukseklik = yukseklik;
		this.yaprakSayisi = yaprakSayisi;
	}
	@Override
	public String toString() {
		return "Cicek [renk=" + renk + ", isim=" + isim + ", tur=" + tur + ", mevsim=" + mevsim + ", koku=" + koku
				+ ", diken=" + diken + ", saksi=" + saksi + ", meyve=" + meyve + ", omur=" + omur + ", yukseklik="
				+ yukseklik + ", yaprakSayisi=" + yaprakSayisi + "]";
	}
	
}
