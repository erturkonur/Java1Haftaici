import java.util.ArrayList;

public class Bilgisayar_test {

	public static void main(String[] args) {
		ArrayList<Bilgisayar> bilgisayar = new ArrayList<>();
		bilgisayar.add(new Bilgisayar("AMD",4,250,2,"Siyah","Microsoft",0,2500));
		bilgisayar.add(new Bilgisayar("Intel",8,500,4,"K�rm�z�","Pardus",1,4500));
		bilgisayar.add(new Bilgisayar("AMD",4,500,4,"Mavi","Microsoft",0,3500));
		bilgisayar.add(new Bilgisayar("Intel",16,1000,8,"Beyaz","Linux",1,6000));
		
		
		for (int i = 0; i < 4; i++) {
			
			System.out.println("Bilgisayar "+(i+1)+"'in" + " �zellikleri: ");
			System.out.println("Bilgisayar i�lemcisi: " + bilgisayar.get(i).getI�lemciMarkasi());
			System.out.println("Ram Boyutu: " + bilgisayar.get(i).getRamBoyutu());
			System.out.println("HDD Boyutu: " + bilgisayar.get(i).getHddBoyutu());
			System.out.println("Ekran Kart� ram: " + bilgisayar.get(i).getEkranKartiRam());
			System.out.println("Bilgisayar rengi:  " + bilgisayar.get(i).getRenk());
			System.out.println("Bilgisayar i�letim sistemi: " + bilgisayar.get(i).getI�letimSistemi());
			if(bilgisayar.get(i).getBilgisayarTipi()==0) {
			System.out.println("Bilgisayar tipi: Masa�st�");	
			}
			else {
			System.out.println("Bilgisayar tipi: Laptop");
			}
			System.out.println("Bilgisayar fiyat�: " + bilgisayar.get(i).getFiyat());
			System.out.println("**************");
			System.out.println("\n");
		}
			
		

	}

}
