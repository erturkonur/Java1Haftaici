import java.util.ArrayList;

public class Cicek_test {

	public static void main(String[] args) {
		ArrayList<Cicek> cicekler = new ArrayList<>();
		cicekler.add(new Cicek("sar�","papatya","otsu","yaz",true,false,true,false,20,25,10));
		cicekler.add(new Cicek("k�rm�z�","g�l","g�l","ilkbahar",true,true,false,true,15,20,25));
		cicekler.add(new Cicek("beyaz","karanfil","karanfil","sonbahar",true,false,false,true,15,10,30));
		for (int i = 0; i < cicekler.size(); i++) {
			System.out.println("Renk: " + cicekler.get(i).getRenk());
			System.out.println("�sim: " + cicekler.get(i).getIsim());
			System.out.println("T�r: "+ cicekler.get(i).getTur());
			System.out.println("Mevsim: " + cicekler.get(i).getMevsim());
			if (cicekler.get(i).isKoku()==true) {
				System.out.println("Koku: Evet");
			}
			else {
				System.out.println("Koku: Hay�r");
			}
			if (cicekler.get(i).isDiken()==true) {
				System.out.println("Diken: Evet");
			}
			else {
				System.out.println("Diken: Hay�r");
			}
			if (cicekler.get(i).isSaksi()==true) {
				System.out.println("Saks�: Evet");
			}
			else {
				System.out.println("Saks�: Hay�r");
			}
			String meyve = cicekler.get(i).isMeyve() ? "Meyve: Evet" : "Meyve: Hay�r" ;
			System.out.println(meyve);
			System.out.println("�mr�: " + cicekler.get(i).getOmur());
			System.out.println("Y�kseklik :" + cicekler.get(i).getYukseklik());
			System.out.println("Yaprak Say�s�: "+cicekler.get(i).getYaprakSayisi());
			System.out.println("-------------------");
			System.out.println(cicekler.get(i));
			System.out.println("-------------------");
		}
		
		
	}

}
