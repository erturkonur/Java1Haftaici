
public class Insan {
	private String ad;
	private String soyad;
	private int do�umYili;
	private String ya�adigiUlke;
	private char cinsiyet;
	private double boy;
	private double kilo;
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getSoyad() {
		return soyad;
	}
	public void setSoyad(String soyad) {
		this.soyad = soyad;
	}
	public int getDo�umYili() {
		return do�umYili;
	}
	public void setDo�umYili(int do�umYili) {
		this.do�umYili = do�umYili;
	}
	public String getYa�adigiUlke() {
		return ya�adigiUlke;
	}
	public void setYa�adigiUlke(String ya�adigiUlke) {
		this.ya�adigiUlke = ya�adigiUlke;
	}
	public char getCinsiyet() {
		return cinsiyet;
	}
	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}
	public double getBoy() {
		return boy;
	}
	public void setBoy(double boy) {
		this.boy = boy;
	}
	public double getKilo() {
		return kilo;
	}
	public void setKilo(double kilo) {
		this.kilo = kilo;
	}
	
	public Insan() {
		
	}
	public Insan(String ad, String soyad, int do�umYili, String ya�adigiUlke, char cinsiyet, double boy, double kilo) {
		super();
		this.ad = ad;
		this.soyad = soyad;
		this.do�umYili = do�umYili;
		this.ya�adigiUlke = ya�adigiUlke;
		this.cinsiyet = cinsiyet;
		this.boy = boy;
		this.kilo = kilo;
	}
	
	
}
