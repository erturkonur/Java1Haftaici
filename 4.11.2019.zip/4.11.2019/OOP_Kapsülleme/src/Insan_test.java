import java.util.ArrayList;

public class Insan_test {

	public static void main(String[] args) {
		ArrayList<Insan> insanlar = new ArrayList<>();
		
		insanlar.add(new Insan("Onur","Ert�rk",1995,"T�rkiye",'e',1.75,76));
		insanlar.add(new Insan("Ahmet","Keser",1999,"T�rkiye",'e',1.70,80));
		insanlar.add(new Insan("Ay�e","Bilir",1966,"Almanya",'k',1.60,90));
		insanlar.add(new Insan("Saliha","Yaz�c�",2010,"Rusya",'k',1.17,15));
		
		for (int i = 0; i < insanlar.size(); i++) {
			System.out.println("Ad: " + insanlar.get(i).getAd());
			System.out.println("Soyad: " + insanlar.get(i).getSoyad());
			System.out.println("Do�um Y�l�: " +insanlar.get(i).getDo�umYili());
			System.out.println("Ya�ad��� �lke: " + insanlar.get(i).getYa�adigiUlke());
			if (insanlar.get(i).getCinsiyet()=='e') {
				System.out.println("Cinsiyet: Erkek");
			}
			else {
				System.out.println("Cinsiyet: Kad�n");
			}
			System.out.println("Boy: " + insanlar.get(i).getBoy()+" m");
			System.out.println("Kilo: " + insanlar.get(i).getKilo()+" kg");
			System.out.println("****************");
		}

	}

}
