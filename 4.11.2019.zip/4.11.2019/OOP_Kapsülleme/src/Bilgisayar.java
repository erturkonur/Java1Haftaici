
public class Bilgisayar {
	
	private String i�lemciMarkasi;
	private double ramBoyutu;
	private double hddBoyutu;
	private double ekranKartiRam;
	private String renk;
	private String i�letimSistemi;
	private int bilgisayarTipi;
	private double fiyat;
	public String getI�lemciMarkasi() {
		return i�lemciMarkasi;
	}
	public void setI�lemciMarkasi(String i�lemciMarkasi) {
		this.i�lemciMarkasi = i�lemciMarkasi;
	}
	public double getRamBoyutu() {
		return ramBoyutu;
	}
	public void setRamBoyutu(double ramBoyutu) {
		this.ramBoyutu = ramBoyutu;
	}
	public double getHddBoyutu() {
		return hddBoyutu;
	}
	public void setHddBoyutu(double hddBoyutu) {
		this.hddBoyutu = hddBoyutu;
	}
	public double getEkranKartiRam() {
		return ekranKartiRam;
	}
	public void setEkranKartiRam(double ekranKartiRam) {
		this.ekranKartiRam = ekranKartiRam;
	}
	public String getRenk() {
		return renk;
	}
	public void setRenk(String renk) {
		this.renk = renk;
	}
	public String getI�letimSistemi() {
		return i�letimSistemi;
	}
	public void setI�letimSistemi(String i�letimSistemi) {
		this.i�letimSistemi = i�letimSistemi;
	}
	public int getBilgisayarTipi() {
		return bilgisayarTipi;
	}
	public void setBilgisayarTipi(int bilgisayarTipi) {
		this.bilgisayarTipi = bilgisayarTipi;
	}
	public double getFiyat() {
		return fiyat;
	}
	public void setFiyat(double fiyat) {
		this.fiyat = fiyat;
	}
	public Bilgisayar() {
		
	}
	public Bilgisayar(String i�lemciMarkasi, double ramBoyutu, double hddBoyutu, double ekranKartiRam, String renk,
			String i�letimSistemi, int bilgisayarTipi, double fiyat) {
		super();
		this.i�lemciMarkasi = i�lemciMarkasi;
		this.ramBoyutu = ramBoyutu;
		this.hddBoyutu = hddBoyutu;
		this.ekranKartiRam = ekranKartiRam;
		this.renk = renk;
		this.i�letimSistemi = i�letimSistemi;
		this.bilgisayarTipi = bilgisayarTipi;
		this.fiyat = fiyat;
	}
	

}

