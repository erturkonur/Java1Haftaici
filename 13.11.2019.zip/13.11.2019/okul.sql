-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 13 Kas 2019, 13:13:38
-- Sunucu sürümü: 10.4.6-MariaDB
-- PHP Sürümü: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `okul`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrenci`
--

CREATE TABLE `ogrenci` (
  `id` int(11) NOT NULL,
  `okul_kayit_tarihi` date NOT NULL,
  `ad` varchar(75) NOT NULL,
  `soyad` varchar(75) NOT NULL,
  `tcno` int(11) NOT NULL,
  `sinif_id` int(3) NOT NULL,
  `adres` varchar(255) NOT NULL,
  `telefon_no` int(11) NOT NULL,
  `dogum_yili` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ogrenci`
--

INSERT INTO `ogrenci` (`id`, `okul_kayit_tarihi`, `ad`, `soyad`, `tcno`, `sinif_id`, `adres`, `telefon_no`, `dogum_yili`) VALUES
(1, '2019-11-12', 'Adem\r\n', 'Köz', 0, 15, 'Beşikltaş/İstanbul', 0, 0),
(2, '2019-11-12', 'Burçin', 'Emişoğlu', 0, 15, 'Beşikltaş/İstanbul', 0, 0),
(3, '2019-11-12', 'Can', 'İkiz', 0, 15, 'Beşikltaş/İstanbul', 0, 0),
(4, '2019-11-12', 'Cem', 'Adanur', 0, 15, 'Beşikltaş/İstanbul', 0, 0),
(5, '2019-11-12', 'Emre', 'Ata', 123456789, 15, 'Beşikltaş/İstanbul', 0, 0),
(6, '2019-11-12', 'İsmail', 'Aşık', 0, 15, 'Beşikltaş/İstanbul', 0, 0),
(7, '2019-11-12', 'Kübra', 'Gökalp', 0, 20, 'Fatih/İstanbul', 0, 0),
(8, '2019-11-12', 'Merve', 'Özdemir', 0, 20, 'Fatih/İstanbul', 0, 0),
(9, '2019-11-12', 'Mesut', 'Avcı', 0, 20, 'Fatih/İstanbul', 0, 0),
(10, '2019-11-12', 'Musa', 'Esmer', 0, 20, 'Fatih/İstanbul', 0, 0),
(11, '2019-11-12', 'Onur', 'Ertürk', 0, 20, 'Fatih/İstanbul', 0, 0),
(12, '2019-11-12', 'Tuba', 'Sarıtaş', 0, 20, 'Fatih/İstanbul', 0, 0),
(13, '2019-11-12', 'Serdar', 'Aslan', 0, 20, 'Fatih/İstanbul', 0, 0),
(14, '2019-11-12', 'Serkan ', 'Çetin', 0, 20, 'Fatih/İstanbul', 0, 0),
(15, '2019-11-12', 'Sümeyye Nur', 'Gernikci', 0, 20, 'Fatih/İstanbul', 0, 0),
(16, '2019-11-12', 'Tuğba', 'Ankışhan', 0, 20, 'Fatih/İstanbul', 0, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sinif`
--

CREATE TABLE `sinif` (
  `id` int(11) NOT NULL,
  `ad` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `sinif`
--

INSERT INTO `sinif` (`id`, `ad`) VALUES
(12, 'Lab 01'),
(13, 'Lab 02'),
(14, 'Lab 03'),
(15, 'Lab 04'),
(16, 'Lab 05'),
(17, 'Lab 06'),
(18, 'Lab 07'),
(19, 'Lab 08'),
(20, 'Lab 09'),
(21, 'Lab 10'),
(22, 'Lab 11');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `ogrenci`
--
ALTER TABLE `ogrenci`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sinif`
--
ALTER TABLE `sinif`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ogrenci`
--
ALTER TABLE `ogrenci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Tablo için AUTO_INCREMENT değeri `sinif`
--
ALTER TABLE `sinif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
