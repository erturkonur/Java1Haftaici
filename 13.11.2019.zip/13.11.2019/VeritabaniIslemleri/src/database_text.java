import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class database_text  {

	public static void main(String[] args) {
		
		database db = new database();
		db.baglatiyiAc("okul","root","","127.0.0.1",3306);
		
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("L�tfen i�lem se�iniz: (��renci ekle,s�n�f ekle,��renci sil,s�n�f sil,��renci say�s�,s�n�f say�s�)");
			
			String islem = sc.next();
			switch (islem) {
			case "��rencilistele":
				ResultSet rs = db.verileriListele("Select * from ogrenci");
				try {
					while(rs.next()) {
						System.out.println("��rencinin ad�:"+rs.getString("ad"));
						System.out.println("��rencinin soyad�:"+rs.getString("soyad"));
						System.out.println("��rencinin T.C.No.:"+rs.getString("tcno"));
						System.out.println("��rencinin S�n�f�:"+rs.getString("sinif_id"));
						System.out.println("��rencinin Adresi:"+rs.getString("adres"));
						System.out.println("��rencinin Telefon No:"+rs.getString("telefon_no"));
						System.out.println("��rencinin ad�:"+rs.getString("dogum_yili"));
						System.out.println("--------");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			case "ogrenciekle":
				System.out.println("L�tfen ��renci bilgilerini giriniz: ");
				System.out.println("��rencinin ad�n� giriniz:");
				String ogrAd = sc.next();
				System.out.println("��rencinin soyad�n� giriniz:");
				String ogrSoyad = sc.next();
				System.out.println("��rencinin TCN giriniz: ");
				int tcNo = sc.nextInt();
				System.out.println("��rencinin s�n�f ID'sini giriniz:");
				int sinif_Id = sc.nextInt();
				System.out.println("��rencinin adresini giriniz: ");
				String adres = sc.next();
				System.out.println("��rencinin tel no giriniz.(int)");
				int telefonNo = sc.nextInt();
				System.out.println("��renci dogum y�l�n� giriniz:");
				int dogumYili = sc.nextInt();
				Date date = new Date();
				db.veriEkle(
						"ogrenci", 
						"okul_kayit_tarihi,ad,soyad,tcno,sinif_id,adres,telefon_no,dogum_yili", 
						"'"+date.toString()+"','"+ogrAd+"','"+ogrSoyad+"',"+tcNo+","+sinif_Id+",'"+adres+"',"+telefonNo+","+dogumYili
						);
				break;
			case "s�n�fekle":
				System.out.println("Eklenecek s�n�f�n ismini yaz�n�z:");
				String sinifAdi = sc.next();
				db.veriEkle("sinif", "ad", "'"+sinifAdi+"'");
				
				break;
			case "��rencisil":
				System.out.println("L�tfen ��renci ID'si giriniz:");
				int ogrenciId = sc.nextInt();
				db.veriSil("ogrenci", "id="+ogrenciId);
				break;
			case "s�n�fsil":
				System.out.println("L�tfen s�n�f ID'si giriniz:");
				int sinifId = sc.nextInt();
				db.veriSil("sinif", "id="+sinifId);
	
				break;
			case "��rencisay�s�":
				int ogrenciSayi = db.tablodakiVeriSayisi("ogrenci");
				System.out.println("��renci tablosundaki sat�r say�s�: "+ogrenciSayi);
				break;
			case "s�n�fsay�s�":
				int sayi = db.tablodakiVeriSayisi("sinif");
				System.out.println("S�n�f tablosundaki sat�r say�s�: "+sayi);
				break;

			default:
				break;
			}
			
			
		}
		
		
	}

	private static LocalDate LocalDate() {
		// TODO Auto-generated method stub
		return null;
	}

}
