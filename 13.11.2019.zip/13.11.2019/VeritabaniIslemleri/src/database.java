import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class database {
	Connection baglanti = null;
	Statement st = null;
	
	public void baglatiyiAc(String veritabaniAdi, String dbUsername, String dbUserPass, String serverIP, int port) {
		String baglantiCumlesi = "jdbc:mysql://" + serverIP + ":" + port + "/" + veritabaniAdi+"?serverTimezone=UTC";
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			baglanti = DriverManager.getConnection(baglantiCumlesi, dbUsername, dbUserPass);
			st = baglanti.createStatement(); // Statement s�n�f�n� Connection s�n�f�na ba�lad�k.
			/*
			 * Connection s�n�f� sayesinde veritaban�na ba�lant� i�lemi yapar�z. Connection
			 * s�n�f�, DriverManager s�n�f�n�n getConnection metoduna ba�lanmas� gerekir. 
			 * --
			 * Statement s�n�f� sayesinde, veritaban� sorgular� yazabiliriz. 
			 * Insert, update, delete, select gibi.. Statemnet s�n�f� executeQuery metodu sayesinde select
			 * sorgusunda bulunabiliriz. executeUpdate metodu sayesinde Insert, update, delete, select i�lemleri i�in kullan�l�r.
			 */
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void baglantiyiKapat() {
		try {
			if (!st.isClosed()) { // statement a��k ise
				st.close();
			}
			if (!baglanti.isClosed()) { // ba�lanti a��k ise
				baglanti.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ResultSet verileriListele(String sorgu) {
		ResultSet rs = null;
		try {
			rs = st.executeQuery(sorgu);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
		/*
		 * ResultSet s�n�f� select sorgusundan d�nen t�m sat�r verilerini tek tek okuyabilmek i�in
		  kullan�lan s�n�ft�r.
		 */
	}
	
	public void sorguGonder(String sorgu) {
		try {
			st.executeUpdate(sorgu);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// Bu metot sayesinde do�rudan Insert,Update ve Delete sorgular� g�nderilebilir.
		// sorguGonder("delete from ogrenciler where id=1")
		// sorguGonder("Insert into ...")
	}
	
	public void veriSil (String tabloAdi, String sart) {
		try {
			st.executeUpdate("Delete from "+tabloAdi+" where " + sart);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//veriSil("ogrenci","id=1"); // delete from ogrenciler where id=1
	}
	
	public int tablodakiVeriSayisi (String tabloAdi) {
		int sonuc=0;
		try {
			ResultSet rs = st.executeQuery("Select count(*) as sayi from " + tabloAdi);
			rs.next();
			sonuc = rs.getInt("sayi");
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sonuc;
		/*
		 Bu metot sayesinde arg�man olarak ald���m�z tabloya ait toplam sat�r say�s�n� bulabiliriz.
		 */
	}
	
	public void veritabaniniSil(String veritabaniAdi) {
		try {
			st.executeUpdate("Drop database " +veritabaniAdi);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void tabloSil(String tabloAdi) {
		try {
			st.executeUpdate("Drop table " + tabloAdi);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void veritabaniUret (String veritabaniAdi) {
		try {
			st.executeUpdate("Create database "+veritabaniAdi);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tabloUret (String tabloAdi, String argumanListesi) {
		// create table sinif(id int PRIMARY KEY AUTO_INCREMENT,ad varchar(25) null);
		try {
			st.executeUpdate("Create table" + tabloAdi +"("+argumanListesi+")");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// "tabloUret("sinif","id int PRIMARY KEY AUTO_INCREMENT,ad varchar(25) null"=; 
	}
	public void veriGuncelle(String tabloAdi,String guncelleme,String sart) {
		try {
			st.executeUpdate("Update "+ tabloAdi +" set " + guncelleme + " where " +sart);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// veriGuncelle("ogrenci","telefon_no=123456","id=9");
	}
	public void veriEkle(String tabloAdi, String eklenecekKolonlar, String eklenecekDegerler) {
		try {
			st.executeUpdate("Insert into " +tabloAdi+ " ("+eklenecekKolonlar+") values ("+eklenecekDegerler+")");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// veriEkle("sinif","ad","'Lab 01'");
		// veriEkle("ogrenci","ad,soyad,dogum_yili","'�erif','g�ng�r',1990");
	}
	public int tablodakiVeriSayisi (String tabloAdi,String sart) {
		int sonuc=0;
		try {
			ResultSet rs = st.executeQuery("Select count(*) as sayi from " + tabloAdi+" where "+sart);
			rs.next();
			sonuc = rs.getInt("sayi");
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sonuc;
		/*
		 Bu metot sayesinde arg�man olarak ald���m�z tablodaki �arta ait toplam sat�r say�s�n� bulabiliriz.
		 */
		// tablodakiVeriSayisi("ogrenci","dogum_yili=2000");
	}
}
