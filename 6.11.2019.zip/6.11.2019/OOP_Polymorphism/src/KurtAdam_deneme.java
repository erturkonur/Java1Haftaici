
public class KurtAdam_deneme {

	public static void main(String[] args) {
		KurtAdam kurtadam = new KurtAdam();
		kurtadam.agla();
		kurtadam.dusun();
		kurtadam.giyin();
		kurtadam.konus();
		kurtadam.yuru();
		kurtadam.kos();
		kurtadam.penceAt();
		kurtadam.saldir();
		kurtadam.ulu();

	}

}
