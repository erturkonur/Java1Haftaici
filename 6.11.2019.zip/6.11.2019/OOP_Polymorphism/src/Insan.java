
public class Insan {
	public void yuru() {
		System.out.println("Y�r�d�m.");
	}
	public void konus() {
		System.out.println("Konu�tum.");
	}
	public void sarkiSoyle() {
		System.out.println("�ark� s�yledim.");
	}
}
