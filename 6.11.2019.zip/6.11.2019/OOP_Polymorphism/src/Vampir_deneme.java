
public class Vampir_deneme {

	public static void main(String[] args) {
		Vampir vam = new Vampir();
		vam.isir();
		vam.konus();
		vam.sarkiSoyle();
		vam.uc();
		vam.yuru();

	}

}
