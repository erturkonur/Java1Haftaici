
public class Adam {
	public void konus() {
		System.out.println("Konu�tum.");
	}
	public void dusun() {
		System.out.println("D���nd�m.");
	}
	public void yuru() {
		System.out.println("Y�r�d�m.");
	}
	public void giyin() {
		System.out.println("Giyindim.");
	}
	public void agla() {
		System.out.println("A�lad�m.");
	}
}
