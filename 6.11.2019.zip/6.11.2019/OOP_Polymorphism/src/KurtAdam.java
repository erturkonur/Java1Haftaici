
public class KurtAdam extends Adam implements Kurt{

	@Override
	public void ulu() {
		System.out.println("Ulu.");
		
	}

	@Override
	public void kos() {
		System.out.println("Ko�.");
		
	}

	@Override
	public void saldir() {
		System.out.println("Sald�r.");
		
	}

	@Override
	public void penceAt() {
		System.out.println("Pen�e at.");
		
	}

}
