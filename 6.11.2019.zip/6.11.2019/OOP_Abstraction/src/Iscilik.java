
public class Iscilik extends Isci {

}
