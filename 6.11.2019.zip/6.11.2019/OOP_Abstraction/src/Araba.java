
public abstract class Araba {
	public void arabaPlaka (String str) {
		System.out.println(str);
	}
}
