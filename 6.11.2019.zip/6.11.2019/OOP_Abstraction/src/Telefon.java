
public class Telefon extends Android {

	@Override
	public void versionNo(int versionNo) {
		
	}

	@Override
	public void codeName(String name) {
		
	}
	
}
