
public class Araba_Deneme {

	public static void main(String[] args) {
		//Araba araba = new Araba(); //Abstract s�n�flarda direkt newleme yap�lamaz. Dolayl� yoldan mewleme yapmak gerekir.
		MotorluTasitlar motorluTasitlar = new MotorluTasitlar();
		motorluTasitlar.arabaPlaka("34 AA 1234");
		
		Araba a = new MotorluTasitlar();
		a.arabaPlaka("34 BB 1234");
	}

}
