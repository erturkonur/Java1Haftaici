
public class Image extends View{

	@Override
	public void onClick() {
		
	}

	@Override
	public void onClickListener(String str) {
		
	}

}
